// Simple start script for Railway
console.log('Starting backend server for Railway...');
require('./backend/server-redis.js');
